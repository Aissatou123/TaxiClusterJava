import java.util.ArrayList;
import java.util.List;
import java.io.*;
 
public class Cluster {
	
	public List<GpsCoord> points;
	public GpsCoord centre;
	public int id;
	
	public Cluster(int id) {
		this.id = id;
		this.points = new ArrayList<GpsCoord>();
		this.centre = null;
	}
 
	public List getPoints() {
		return points;
	}
	
	public void addPoint(GpsCoord point) {
		points.add(point);
	}
 
	public void setPoints(List points) {
		this.points = points;
	}
 
	public GpsCoord getCentre() {
		return centre;
	}
 
	public void setCentroid(GpsCoord centre) {
		this.centre = centre;
	}
 
	public int getId() {
		return id;
	}
	
	public void clear() {
		points.clear();
	}
	
	public void clusterView() {
		
		System.out.println("[Cluster: " + id+"]");
		System.out.println("[Centroid: " + centre + "]");
		System.out.println("[Points: \n");
		for(GpsCoord p : points) {
			System.out.println(p);
		}
		System.out.println("]");
	}
 
}

// je me suis beaucoup inspiré du site https://www.dataonfocus.com/dbscan-java-code/