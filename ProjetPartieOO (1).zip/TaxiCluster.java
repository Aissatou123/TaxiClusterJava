public class TaxiCluster{
	/*classe principale qui retourne les information d'un groupe de point de départ de mes taxis
	Cette classe utilise toutes les autres classes directement ou indirectement
	elle a deux attributs minPts et eps; 
	Grâce à DBScan on va pouvoir former des groupes de cluster
	*/

	final double EPS=0.0001;
	final int minPts=5;
	String r;

	public static void main (String[] args){
		DBScan myTest= new DBScan(eps,minPts);
		
		//CsvFirst myDocTest= new CsvFirst(r);
		//myDocTest.csvWrite()
	}
	

}