import java.util.ArrayList;
import java.util.List;

public class classManager{

    /* Cette classe me permet de bien manager mes informations pour GpsCoord et TripRecord
    Je peux enregistrier tous mes GpsCoord ainsi que tous mes TripRecord */

	private float latit;
	private float longit;
	public CsvFirst docGPS;
	private ArrayList<ArrayList<String>> myCoordDep;
	private ArrayList<ArrayList<String>> myCoordArr;
	private ArrayList<ArrayList<String>> myInfoTab;
	private List<TripRecord> myTabTrip;
	private List<GpsCoord> tabDep;
	private List<GpsCoord> tabArr;
	private List<TripRecord> tabInff;
	private GpsCoord gps1;
	private GpsCoord gps2;


    //constructeur
	public classManager(String str){
		docGPS= new CsvFirst(str);
	}


	/*Notre méthode importe notre tableau de Coordonné lu par CsvFirst*/
	public void importInfo(){
		ArrayList<ArrayList<String>> tableau= new ArrayList<ArrayList<String>>();
		List<List<String>> l = new ArrayList<>();
		List<String> m= new ArrayList<>();
		String j="";
		String k="";
		myCoordDep = docGPS.coordDepart(tableau,l,m,j,k);
		myCoordArr = docGPS.coordArrive(tableau,l,m,j,k);
		myInfoTab = docGPS.infoVoyage(tableau,l,j,k);

	}

	/*Notre méthode va enregistrer tous nos GpsCoord de départ dans un tableau*/
	public List<GpsCoord> stockCoordDep(){
		for(int i=0; i<myCoordDep.size();i++){
		ArrayList<String> uno = myCoordArr.get(i); 
		latit = Float.parseFloat(uno.get(0)) ;
		longit = Float.parseFloat(uno.get(1)) ;
		gps1=new GpsCoord(latit,longit);
		tabDep.add(gps1);

	}
	return tabDep;
}


	public  List<GpsCoord> stockCoordArr(){
		for(int i=0; i<myCoordArr.size();i++){
		ArrayList<String> uno = myCoordArr.get(i); 
		latit = Float.parseFloat(uno.get(0)) ;
		longit = Float.parseFloat(uno.get(1)) ;
		gps2=new GpsCoord(latit,longit);
		tabArr.add(gps2);

	} 
	return tabArr;
}

    /*Notre méthode enregistre tous nos TripRecord dans un tableau*/
    public List<TripRecord> stockInfo(){
    	for(int i=0; i<myInfoTab.size();i++){
    		ArrayList<String> dos = myInfoTab.get(i);
    		String depart = dos.get(0);
    		GpsCoord pickupLoc = tabDep.get(i);
    		GpsCoord dropOffLoc = tabArr.get(i);
    		float tripDist = Float.parseFloat(dos.get(1));
    		TripRecord tripRec = new TripRecord(depart,pickupLoc,dropOffLoc,tripDist);
    		tabInff.add(tripRec);  
    	}
    	return tabInff;

    }



}
	

