import java.util.ArrayList;

public class TripRecord{
	private String pickup_DateTime;
    private GpsCoord pickup_Location; 
    private GpsCoord dropoff_Location; 
    private float trip_Distance;
    

    
    public TripRecord(String pickup_DateTime, GpsCoord pickup_Location,GpsCoord dropoff_Location,float trip_Distance){
        this.pickup_DateTime=pickup_DateTime;
        this.pickup_Location=pickup_Location;
        this.dropoff_Location=dropoff_Location;
        this.trip_Distance=trip_Distance;

     }

     public String getPickupDateTime(){
        return pickup_DateTime;
     }
     public GpsCoord getPickupLocation(){
        return pickup_Location;
     }

     public GpsCoord getDropOffLocation(){
        return dropoff_Location;
     }

     public float getTripDistance(){
        return trip_Distance;
     }


}