//package com.dataonfocus.clustering.density;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
 
/*import com.dataonfocus.clustering.Algorithm;
import com.dataonfocus.clustering.structures.Cluster;
import com.dataonfocus.clustering.structures.DataPoint;*/
 
public class DBScan implements Access{
    
    public List<GpsCoord> points;
    private List clusters;
    
    public double eps;
    public int minPts;
    
    public boolean[] visited;
    
    public DBScan (double eps, int minPts) {
        this.points = new ArrayList<GpsCoord>();
        this.clusters = new ArrayList();
        this.eps = eps;
        this.minPts = minPts;
    }
 
    public void cluster() {
        for(int i=0;i<points.size();i++){
        GpsCoord it = points.get(i);
        int n = 0;
            
            if(!visited[n]) {
                GpsCoord d = points.get(i+1);
                visited[n] = true;
                List neighbors = getNeighbors(d);
                
                if(neighbors.size() >= minPts) {
                    Cluster c = new Cluster(clusters.size());
                    buildCluster(d,c,neighbors);
                    clusters.add(c);
                }
            }
        }
    }
 
    private void buildCluster(GpsCoord d, Cluster c, List<Integer> neighbors) {
        c.addPoint(d);
        
        for (Integer point : neighbors) {
            GpsCoord p = points.get(point);
            if(!visited[point]) {
                visited[point] = true;
                List newNeighbors = getNeighbors(p);
                if(newNeighbors.size() >= minPts) {
                    neighbors.addAll(newNeighbors);
                }
            }
            if(p.getLat() == -1) {
                c.addPoint(p);
            }
        }
    }
 
    private List getNeighbors(GpsCoord d) {
        List neighbors = new ArrayList();
        int i = 0;
        for (GpsCoord point : points) {
            double distance = d.distanceCoord(point,d);
            
            if(distance <= eps) {
                neighbors.add(i);
            }
            i++;
        }
        
        return neighbors;
    }
 
    public void setPoints(List points) {
        this.points = points;
        this.visited = new boolean[points.size()];
    }
    
}
/* CODE SOURCE: https://www.dataonfocus.com/dbscan-java-code/ */