import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
public class CsvFirst{
	/*Cette classe est la plus importante car elle me permet de récupérer toutes les informations
	se trouvant dans mon fichier csv contenant les nombreuses voyage de taxi
	elle me permettra aussi d'écrire mes résultat dans un fichier CSV afin de pouvoir les visualiser 
	Dans mes autres classe j'aurai juste à faire des appelles des méthodes de csvFirst pour travailler 
	*/
    
	private PrintWriter writer ;
	private List<List<String>> records; 
	private File fichier;
	
    
    //Constructeur
    public CsvFirst(String note){
    	fichier=new File(note);
    }


    //Notre méthode nous permet d'écrire dans un fichier csv tout nouveau
	public void csvWrite(String[] tab, String monFile){
		try{
		writer = new PrintWriter(monFile);
	}
	catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
	    String chaine="";
		
		for(int i=0; i<tab.length-1;i++){
			chaine = chaine + tab[i]+",";
		}
		chaine = chaine +"\n";
		writer.write(chaine);
		writer.close();
	}
	
	
	//Notre méthode lit notre fichier csv où les informations de voyage se trouvent
	public List<List<String>> readCsv(){
		fichier=new File("Test_Input.csv");
		records = new ArrayList<>();
        try (Scanner scanner = new Scanner(fichier);) {
            while (scanner.hasNextLine()) {
                records.add(readLine(scanner.nextLine()));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return (records);
    }

	//Notre méthode retourne une laisse des lignes de notre CSV 
	public List<String> readLine(String line) {
        List<String> values = new ArrayList<String>();
        try (Scanner rowScanner = new Scanner(line)) {
            rowScanner.useDelimiter(";");
            while (rowScanner.hasNext()) {
                values.add(rowScanner.next());
            }
        }
        return values;
    }
    //Notre méthode retourne une liste contenant le couple de coordonnés de chaque point de départ mais en String
    public  ArrayList<ArrayList<String>> coordDepart(ArrayList<ArrayList<String>> tabDepart,List<List<String>> first,
    List<String> second,String x,String y){
    	tabDepart=new ArrayList<ArrayList<String>>();

    	first= readCsv();
    	for(int i=1; i<records.size(); i++){
    		second=first.get(i);
    		x=second.get(9);
    		y=second.get(8);

    	
    		ArrayList<String> n= new ArrayList<String>();
        n.add(x);
        n.add(y);
      

    		tabDepart.add(n);
    	}
    	return(tabDepart);
	}

	//Notre méthode retourne une liste contenant le couple de coordonnés de chaque point d'arrivé mais en String
    public  ArrayList<ArrayList<String>> coordArrive(ArrayList<ArrayList<String>> tabArrive, List<List<String>> firs,
    List<String> secon, String xx, String yy){
    	tabArrive=new ArrayList<ArrayList<String>>();

    	firs= readCsv();
    	for(int i=1; i<records.size(); i++){
    		secon=firs.get(i);
    		xx=secon.get(13);
    		yy=secon.get(12);

    	
    		ArrayList<String> nn= new ArrayList<String>();
            nn.add(xx);
            nn.add(yy);
     

    		tabArrive.add(nn);
    	}
    	return(tabArrive);
	}
	

	//méthode qui importe mes infos pour tripRecord
	public  ArrayList<ArrayList<String>> infoVoyage(ArrayList<ArrayList<String>> tab_of_info, List<List<String>> aTab,
    String a,String c){

    	tab_of_info=new ArrayList<ArrayList<String>>();
    	aTab= readCsv();

    	for(int i=1; i<records.size(); i++){
    		List<String> exemple= aTab.get(i);
    		a=exemple.get(4);
    		c=exemple.get(7);
    		ArrayList<String> y= new ArrayList<String>();
        y.add(a);
        y.add(c);

      tab_of_info.add(y);
    	}
    	return(tab_of_info);
	}

	//méthode main pour tester
	public static void main (String[] args){
		CsvFirst myFirst = new CsvFirst("doc.csv");
		String[] tableau= {"G1","G2","G3","G4"};
		myFirst.csvWrite(tableau,"doc.csv");
		myFirst.readCsv();
		System.out.println("les tableaux de coordonnés");
		ArrayList<ArrayList<String>> tabExp = new ArrayList<ArrayList<String>>();
		List<List<String>> exx = new ArrayList<>();
		String xex="";
		String xxe="";
		System.out.println(myFirst.infoVoyage(tabExp,exx,xex,xxe));

		
	}
}