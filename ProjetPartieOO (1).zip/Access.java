import java.util.List;
//Interface permettant de faciliter le codage de ma classe cluster
 
public interface Access {
 
public void setPoints(List GpsCoord);
 
public void cluster();
 
}