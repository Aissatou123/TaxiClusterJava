import static java.lang.Math.sqrt;

public class GpsCoord{
	private float latitude;
	private float longitude;
	private float lat1;
	private float lont1;
	private float lat2;
	private float lont2;

	public GpsCoord(float latitude,float longitude){
		this.latitude=latitude;
		this.longitude=longitude;
	}
	/*Notre méthode calcule la distance entre deux coordonnés GPS*/

	public double distanceCoord(GpsCoord pointA, GpsCoord pointB){
		pointA= new GpsCoord(lat1,lont1);
		pointB= new GpsCoord(lat2,lont2);
        double distance = Math.sqrt(((lat2 - lat1)*2) + ((lont2 - lont1)*2));
        return distance;
 

	}


	public float getLat(){
		return this.latitude;
	}

	public float getLongit(){
		return this.longitude;
	}




}